var x = false;
console.log(x);
console.log(typeof(x));

var x= 5;
console.log(x)
console.log(typeof(x));

var x = "5";
console.log(x)
console.log(typeof(x));
